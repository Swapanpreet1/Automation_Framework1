package com.automation.framework.browsersetup;

public enum BrowserType {
	Chrome,Safari,Firefox;
}
